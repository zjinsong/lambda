import boto3
import os
import gzip
import json
import time, datetime

s3_client = boto3.client('s3')

def lambda_handler(event, context):
	# TODO implement
	tmpFile = '/tmp/temp.gz'


	batchSize = 10000
	times = 0
	#print(event)
	records = event['Records']
	s3 = boto3.resource('s3')
	
	#change to your es
	for record in records:
		s3Info = record['s3']
		s3BucketName = s3Info['bucket']['name']
		print(s3BucketName)
		objectKey = s3Info['object']['key']
		print(objectKey)
		s3.meta.client.download_file(s3BucketName, objectKey, tmpFile)
		print('Download file:'+ objectKey+' from bucket:'+s3BucketName)
		
		gzFile = gzip.open(tmpFile, 'rt')
		print('open gzFile')
		i = 0
		now = int(time.time())
		csvfile = open('/tmp/'+str(now)+'-'+str(times)+'.csv','w')
		for line in gzFile:
			#print(line)
			csvfile.write(line)
			i = i + 1
			if (i == batchSize):
				csvfile.close()
				
				uploadS3('/tmp/'+str(now)+'-'+str(times)+'.csv', s3BucketName)
				os.remove('/tmp/'+str(now)+'-'+str(times)+'.csv')
				times = times + 1
				i = 0
				csvfile =open('/tmp/'+str(now)+'-'+str(times)+'.csv','w')
		csvfile.close()
		if (os.path.exists('/tmp/'+str(now)+'-'+str(times)+'.csv')):
			uploadS3('/tmp/'+str(now)+'-'+str(times)+'.csv', s3BucketName)
			os.remove('/tmp/'+str(now)+'-'+str(times)+'.csv')
			times = times + 1 
			
		gzFile.close()
		os.remove(tmpFile)
		
	return {
		'statusCode': 200,
		'body': json.dumps('done!')
	}
def uploadS3(key, bucketName):
	print('start to upload csv file ' + key + ' to s3')
	s3_client.upload_file(key, bucketName, key)
	print('upload completed')

